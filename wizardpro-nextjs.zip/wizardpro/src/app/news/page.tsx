import WizardApp from '@/components/WizardApp';

export default function NewsPage() {
  return <WizardApp />;
}
