'use client';

import { useState, useEffect, useCallback } from 'react';
import type { AppSettings } from '@/types';
import { storageGet, storageSet } from '@/utils';
import { STORAGE_KEYS } from '@/constants';

const DEFAULT_SETTINGS: AppSettings = {
  theme: 'dark',
  notifications: true,
  soundAlerts: false,
  marketHours: true,
};

export function useSettings() {
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);

  useEffect(() => {
    const stored = storageGet<AppSettings>(STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS);
    setSettings(stored);

    // Apply theme
    if (typeof document !== 'undefined') {
      document.documentElement.setAttribute('data-theme', stored.theme);
    }
  }, []);

  const updateSettings = useCallback((next: AppSettings) => {
    setSettings(next);
    storageSet(STORAGE_KEYS.SETTINGS, next);
    if (typeof document !== 'undefined') {
      document.documentElement.setAttribute('data-theme', next.theme);
    }
  }, []);

  return { settings, updateSettings };
}
