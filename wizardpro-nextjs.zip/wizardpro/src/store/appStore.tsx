'use client';

import { createContext, useContext, useReducer, type ReactNode } from 'react';
import type { AppSettings } from '@/types';

// ── State ────────────────────────────────────────────────────────────────────

interface AppState {
  currentTab: 'community' | 'fundamental' | 'tradelab' | 'news';
  isAuthModalOpen: boolean;
  isSettingsOpen: boolean;
  isNotificationsOpen: boolean;
  toastMessage: string;
  toastVisible: boolean;
  settings: AppSettings;
  paperBalance: number;
}

const INITIAL_STATE: AppState = {
  currentTab: 'community',
  isAuthModalOpen: false,
  isSettingsOpen: false,
  isNotificationsOpen: false,
  toastMessage: '',
  toastVisible: false,
  settings: {
    theme: 'dark',
    notifications: true,
    soundAlerts: false,
    marketHours: true,
  },
  paperBalance: 500_000,
};

// ── Actions ──────────────────────────────────────────────────────────────────

type AppAction =
  | { type: 'SET_TAB'; tab: AppState['currentTab'] }
  | { type: 'OPEN_AUTH' }
  | { type: 'CLOSE_AUTH' }
  | { type: 'OPEN_SETTINGS' }
  | { type: 'CLOSE_SETTINGS' }
  | { type: 'OPEN_NOTIFICATIONS' }
  | { type: 'CLOSE_NOTIFICATIONS' }
  | { type: 'SHOW_TOAST'; message: string }
  | { type: 'HIDE_TOAST' }
  | { type: 'UPDATE_SETTINGS'; settings: AppSettings }
  | { type: 'UPDATE_BALANCE'; amount: number };

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_TAB':           return { ...state, currentTab: action.tab };
    case 'OPEN_AUTH':         return { ...state, isAuthModalOpen: true };
    case 'CLOSE_AUTH':        return { ...state, isAuthModalOpen: false };
    case 'OPEN_SETTINGS':     return { ...state, isSettingsOpen: true };
    case 'CLOSE_SETTINGS':    return { ...state, isSettingsOpen: false };
    case 'OPEN_NOTIFICATIONS':return { ...state, isNotificationsOpen: true };
    case 'CLOSE_NOTIFICATIONS': return { ...state, isNotificationsOpen: false };
    case 'SHOW_TOAST':        return { ...state, toastMessage: action.message, toastVisible: true };
    case 'HIDE_TOAST':        return { ...state, toastVisible: false };
    case 'UPDATE_SETTINGS':   return { ...state, settings: action.settings };
    case 'UPDATE_BALANCE':    return { ...state, paperBalance: action.amount };
    default:                  return state;
  }
}

// ── Context ──────────────────────────────────────────────────────────────────

interface AppContextValue {
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, INITIAL_STATE);
  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppStore() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useAppStore must be used within AppProvider');
  return ctx;
}
