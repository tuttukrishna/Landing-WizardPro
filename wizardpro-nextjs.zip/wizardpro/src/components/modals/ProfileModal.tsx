'use client';

import type { User } from '@/types';

interface ProfileModalProps {
  isOpen: boolean;
  user?: User | null;
  onClose: () => void;
  onFollow?: (userId: string) => void;
  onMessage?: (userId: string) => void;
  onViewTrades?: (userId: string) => void;
}

export default function ProfileModal({
  isOpen,
  user,
  onClose,
  onFollow,
  onMessage,
  onViewTrades,
}: ProfileModalProps) {
  if (!isOpen || !user) return null;

  return (
    <div
      className="profile-overlay show"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="profile-sheet" id="profileModalSheet">
        <div className="profile-hero">
          <div
            className="profile-avatar-lg"
            style={{ background: user.avatarColor ?? 'var(--accent)' }}
          />
          <div className="profile-name-big">{user.name}</div>
          <div className="profile-handle">{user.handle}</div>
          <div className="profile-stats">
            <div>
              <span className="profile-stat-val">{user.posts ?? 0}</span>
              <span className="profile-stat-lbl">Posts</span>
            </div>
            <div>
              <span className="profile-stat-val">{user.followers ?? 0}</span>
              <span className="profile-stat-lbl">Followers</span>
            </div>
            <div>
              <span className="profile-stat-val">{user.following ?? 0}</span>
              <span className="profile-stat-lbl">Following</span>
            </div>
          </div>
        </div>

        {/* Action buttons */}
        <div className="pm-action-row" style={{ display: 'flex', gap: 8, padding: '12px 20px' }}>
          <button
            className="pm-trade-btn-pro"
            onClick={() => { onClose(); onViewTrades?.(user.id); }}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" style={{ width: 14, height: 14 }}>
              <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
            </svg>
            Trades
          </button>
          <button
            className="pm-msg-btn-pro"
            onClick={() => { onClose(); onMessage?.(user.id); }}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" style={{ width: 14, height: 14 }}>
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
            </svg>
            Message
          </button>
          <button
            onClick={() => { onFollow?.(user.id); }}
            style={{
              padding: '8px 16px',
              borderRadius: 99,
              background: 'var(--accent)',
              color: '#fff',
              border: 'none',
              fontSize: 13,
              fontWeight: 700,
              cursor: 'pointer',
            }}
          >
            Follow
          </button>
        </div>

        {/* Stats if trader */}
        {user.winRate && (
          <div style={{ padding: '0 20px 16px', display: 'flex', gap: 10 }}>
            <div style={{ flex: 1, background: 'var(--bg3)', borderRadius: 10, padding: 12, border: '1px solid var(--border)' }}>
              <div style={{ fontSize: 10, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Win Rate</div>
              <div style={{ fontSize: 18, fontWeight: 800, color: 'var(--green)' }}>{user.winRate}</div>
            </div>
            <div style={{ flex: 1, background: 'var(--bg3)', borderRadius: 10, padding: 12, border: '1px solid var(--border)' }}>
              <div style={{ fontSize: 10, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>P&amp;L</div>
              <div style={{ fontSize: 18, fontWeight: 800, color: 'var(--green)' }}>{user.pnl}</div>
            </div>
            <div style={{ flex: 1, background: 'var(--bg3)', borderRadius: 10, padding: 12, border: '1px solid var(--border)' }}>
              <div style={{ fontSize: 10, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Trades</div>
              <div style={{ fontSize: 18, fontWeight: 800 }}>{user.trades}</div>
            </div>
          </div>
        )}

        <div className="profile-divider" />
        <div className="profile-menu">
          <div className="profile-menu-item" onClick={onClose}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            Close
          </div>
        </div>
      </div>
    </div>
  );
}
