'use client';

import { useState, useCallback } from 'react';
import Feed from '@/components/feed/Feed';
import CommentModal from '@/components/modals/CommentModal';
import type { Post } from '@/types';

interface CommunitySectionProps {
  currentUser: { name: string; handle: string } | null;
  onNewPost?: () => void;
  onSearch?: () => void;
}

// Demo seed posts
const DEMO_POSTS: Post[] = [
  {
    id: 1, user: 'Arjun Mehta', handle: '@arjun_trades',
    avatarColor: '#7b61ff', tag: 'bull', likes: 142, comments: 18, time: '2h ago',
    content: '<strong>NIFTY</strong> holding 24,100 support. Watching for a breakout above 24,285 with IT and FMCG leadership. Risk defined at 23,980. <span class="ticker-ref">$NIFTY</span>',
  },
  {
    id: 2, user: 'Priya Sharma', handle: '@priya_folio',
    avatarColor: '#00d4aa', tag: 'options', likes: 89, comments: 12, time: '4h ago',
    content: 'Sold BANKNIFTY 48,500 PE for ₹180. Premium decay working in my favour. Delta neutral stance today. <span class="ticker-ref">$BANKNIFTY</span>',
  },
  {
    id: 3, user: 'Vikram Nair', handle: '@vikram_macro',
    avatarColor: '#ff6b35', tag: 'macro', likes: 234, comments: 45, time: '6h ago',
    content: 'Crude below $62 is net positive for India — watch for OMC stocks to outperform. HAL and BEL looking technically strong. This is not investment advice.',
  },
  {
    id: 4, user: 'Sneha Patel', handle: '@sneha_swing',
    avatarColor: '#f7c59f', tag: 'bear', likes: 67, comments: 8, time: '8h ago',
    content: 'TCS approaching key resistance at ₹3,450. If it fails, next support at ₹3,280. Watching Infosys for confirmation. <span class="ticker-ref">$TCS</span>',
  },
  {
    id: 5, user: 'Rohan Gupta', handle: '@rohan_quant',
    avatarColor: '#2dd4bf', tag: 'news', likes: 312, comments: 67, time: '12h ago',
    content: 'RBI held rates as expected. Focus now shifts to monsoon data and Q1 FY27 results. Market breadth improving — mid-cap rally may extend.',
  },
];

export default function CommunitySection({ currentUser, onNewPost, onSearch }: CommunitySectionProps) {
  const [posts, setPosts] = useState<Post[]>(DEMO_POSTS);
  const [commentModal, setCommentModal] = useState<{ open: boolean; postId?: number | string }>({ open: false });

  const handleComment = useCallback((postId: number | string) => {
    setCommentModal({ open: true, postId });
  }, []);

  const handleCommentSubmit = useCallback((text: string, postId: number | string) => {
    setPosts((prev) =>
      prev.map((p) => p.id === postId ? { ...p, comments: p.comments + 1 } : p)
    );
  }, []);

  return (
    <div className="tab-screen active" id="screen-community">
      {/* Header row */}
      <div className="community-header-row">
        <div className="community-title-label">Community</div>
        <button className="search-trigger-pill" onClick={onSearch}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" style={{ width: 14, height: 14, flexShrink: 0 }}>
            <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
          <span>Search traders...</span>
        </button>
      </div>

      {/* Feed */}
      <Feed
        posts={posts}
        onPostClick={(id) => {
          // openPostDetail equivalent - handled by global JS in WizardApp mode
          if (typeof window !== 'undefined' && (window as unknown as Record<string,unknown>).openPostDetail) {
            ((window as unknown as Record<string,unknown>).openPostDetail as (id: unknown) => void)(id);
          }
        }}
        onAvatarClick={(handle) => {
          if (typeof window !== 'undefined' && (window as unknown as Record<string,unknown>).openUserProfile) {
            ((window as unknown as Record<string,unknown>).openUserProfile as (h: string) => void)(handle);
          }
        }}
      />

      {/* New post FAB */}
      {currentUser && (
        <button className="premium-fab" onClick={onNewPost} style={{ zIndex: 150 }}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" style={{ width: 22, height: 22 }}>
            <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
          </svg>
        </button>
      )}

      {/* Comment modal */}
      <CommentModal
        isOpen={commentModal.open}
        postId={commentModal.postId}
        onClose={() => setCommentModal({ open: false })}
        onSubmit={handleCommentSubmit}
      />
    </div>
  );
}
