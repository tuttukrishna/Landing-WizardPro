import WizardApp from '@/components/WizardApp';

export default function SettingsPage() {
  return <WizardApp />;
}
