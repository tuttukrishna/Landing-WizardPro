'use client';

import { useState, useEffect } from 'react';
import type { MarketIndex, SectorData } from '@/types';
import { MARKET_INDICES, SECTOR_DATA } from '@/constants';

interface MarketData {
  indices: typeof MARKET_INDICES;
  sectors: typeof SECTOR_DATA;
  moodValue: number;
  lastUpdated: string;
}

/**
 * useMarketData
 * ─────────────
 * Returns static demo market data. In production, replace
 * the fetch logic with a real-time API (e.g. Yahoo Finance, NSE).
 */
export function useMarketData(): MarketData & { loading: boolean } {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API delay
    const id = setTimeout(() => setLoading(false), 600);
    return () => clearTimeout(id);
  }, []);

  return {
    loading,
    indices: MARKET_INDICES,
    sectors: SECTOR_DATA,
    moodValue: 62,
    lastUpdated: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
  };
}
