export { default as APP_HTML } from './appHtml';
