'use client';

import { MARKET_INDICES, SECTOR_DATA } from '@/constants';

/**
 * MarketOverview
 * ──────────────
 * Displays the market indices grid and sector bar chart
 * for the Fundamental tab's Overview sub-section.
 */
export default function MarketOverview() {
  const moodValue = 62;

  return (
    <div>
      {/* Indices grid */}
      <div className="market-overview-grid">
        {MARKET_INDICES.map((idx) => (
          <div key={idx.name} className="mkt-card">
            <div className="mkt-card__label">{idx.name}</div>
            <div className="mkt-card__val">{idx.value}</div>
            <div className={`mkt-card__chg ${idx.isUp ? 'pos' : 'neg'}`}>
              {idx.isUp ? '▲' : '▼'} {idx.changePct}
            </div>
          </div>
        ))}

        {/* Fear & Greed */}
        <div className="mkt-card span2">
          <div className="mkt-card__label">Market Mood — Fear &amp; Greed</div>
          <div className="mkt-mood-bar">
            <div
              className="mkt-mood-pin"
              style={{ left: `${moodValue}%` }}
            />
          </div>
          <div className="mkt-mood-labels">
            <span>Extreme Fear</span>
            <span>Neutral</span>
            <span>Extreme Greed</span>
          </div>
          <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--accent)', marginTop: 4 }}>
            {moodValue} — Greed
          </div>
        </div>

        {/* Sectors */}
        <div className="mkt-card span2">
          <div className="mkt-card__label" style={{ marginBottom: 8 }}>Sector Performance</div>
          <div className="sector-list">
            {SECTOR_DATA.map((s) => (
              <div key={s.name} className="sector-row">
                <span className="sector-name">{s.name}</span>
                <div className="sector-bar">
                  <div
                    className={`sector-fill ${s.isUp ? 'pos' : 'neg'}`}
                    style={{ width: `${Math.abs(s.change) * 30}%` }}
                  />
                </div>
                <span className={`sector-pct ${s.isUp ? 'pos' : 'neg'}`}>
                  {s.isUp ? '+' : ''}{s.change.toFixed(2)}%
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
