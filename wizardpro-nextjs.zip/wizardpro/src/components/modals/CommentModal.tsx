'use client';

import { useState, useEffect, useRef } from 'react';

interface Comment {
  id: string;
  user: string;
  handle: string;
  text: string;
  time: string;
  likes: number;
}

interface CommentModalProps {
  isOpen: boolean;
  postId?: number | string;
  onClose: () => void;
  onSubmit?: (text: string, postId: number | string) => void;
  comments?: Comment[];
}

export default function CommentModal({
  isOpen,
  postId,
  onClose,
  onSubmit,
  comments = [],
}: CommentModalProps) {
  const [text, setText] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => textareaRef.current?.focus(), 300);
    } else {
      setText('');
    }
  }, [isOpen]);

  const handleSubmit = () => {
    if (!text.trim() || postId == null) return;
    onSubmit?.(text.trim(), postId);
    setText('');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="modal-overlay show" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal-sheet">
        <div className="modal-handle" />
        <div className="modal-title">
          Comments
          <span className="modal-close" onClick={onClose}>×</span>
        </div>

        {/* Existing comments */}
        <div style={{ maxHeight: '40vh', overflowY: 'auto', marginBottom: 12 }}>
          {comments.length === 0 ? (
            <div style={{ textAlign: 'center', color: 'var(--text3)', fontSize: 13, padding: '20px 0' }}>
              No comments yet. Be the first!
            </div>
          ) : (
            comments.map((c) => (
              <div key={c.id} style={{ marginBottom: 12, padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 4 }}>
                  <div className="avatar" style={{ width: 28, height: 28, fontSize: 11, background: 'var(--accent)' }} />
                  <span style={{ fontWeight: 700, fontSize: 13 }}>{c.user}</span>
                  <span style={{ fontSize: 11, color: 'var(--text3)' }}>{c.handle}</span>
                  <span style={{ fontSize: 10, color: 'var(--text3)', marginLeft: 'auto' }}>{c.time}</span>
                </div>
                <p style={{ fontSize: 13, color: 'var(--text2)', lineHeight: 1.6 }}>{c.text}</p>
              </div>
            ))
          )}
        </div>

        {/* Compose */}
        <textarea
          ref={textareaRef}
          className="post-compose-area"
          placeholder="Add a comment…"
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={3}
        />
        <button className="publish-btn" onClick={handleSubmit} disabled={!text.trim()}>
          Post Comment
        </button>
      </div>
    </div>
  );
}
