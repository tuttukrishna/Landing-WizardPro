'use client';

interface TradingChartProps {
  symbol?: string;
  height?: number;
}

/**
 * TradingChart
 * ────────────
 * Placeholder for the TradingView chart integration.
 * In production, replace with TradingView widget or Recharts.
 */
export default function TradingChart({ symbol = 'NIFTY', height = 280 }: TradingChartProps) {
  return (
    <div
      style={{
        width: '100%',
        height,
        background: 'var(--bg3)',
        border: '1px solid var(--border)',
        borderRadius: 12,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'column',
        gap: 8,
        color: 'var(--text3)',
      }}
    >
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth={1.5}
        style={{ width: 32, height: 32, opacity: 0.4 }}
      >
        <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
      </svg>
      <div style={{ fontSize: 12, fontWeight: 600 }}>{symbol} Chart</div>
      <div style={{ fontSize: 11, opacity: 0.6 }}>Live chart coming soon</div>
    </div>
  );
}
