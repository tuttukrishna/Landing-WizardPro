'use client';

import { useState, useMemo } from 'react';
import PostCard from '@/components/cards/PostCard';
import type { Post, PostTag } from '@/types';

interface FeedProps {
  posts: Post[];
  onPostClick?: (id: number | string) => void;
  onAvatarClick?: (handle: string) => void;
}

type FilterOption = 'all' | PostTag;

const FILTERS: { id: FilterOption; label: string; icon: string }[] = [
  { id: 'all',     label: 'All',        icon: '⌂' },
  { id: 'bull',    label: 'Intraday',   icon: '⚡' },
  { id: 'bear',    label: 'Swing',      icon: '📈' },
  { id: 'options', label: 'F&O',        icon: '⎔' },
  { id: 'macro',   label: 'Commodities',icon: '🪙' },
  { id: 'news',    label: 'News',       icon: '◉' },
];

/**
 * Feed
 * ────
 * Community feed with segmented filter bar and post cards.
 */
export default function Feed({ posts, onPostClick, onAvatarClick }: FeedProps) {
  const [activeFilter, setActiveFilter] = useState<FilterOption>('all');

  const filtered = useMemo(() => {
    if (activeFilter === 'all') return posts;
    return posts.filter((p) => p.tag === activeFilter);
  }, [posts, activeFilter]);

  return (
    <div>
      {/* Filter bar */}
      <div className="community-filter-bar">
        <div className="seg-track" id="seg-community">
          {FILTERS.map(({ id, label, icon }) => (
            <div
              key={id}
              className={`filter-pill${activeFilter === id ? ' active' : ''}`}
              data-filter={id}
              onClick={() => setActiveFilter(id)}
            >
              <span className="pill-icon">{icon}</span>
              {label}
            </div>
          ))}
        </div>
      </div>

      {/* Posts */}
      <div className="community-feed" id="communityFeed">
        {filtered.length === 0 ? (
          <div className="empty-state">
            <p>No posts in this category yet.</p>
          </div>
        ) : (
          filtered.map((post) => (
            <PostCard
              key={post.id}
              post={post}
              onCardClick={onPostClick}
              onAvatarClick={onAvatarClick}
            />
          ))
        )}
      </div>
    </div>
  );
}
