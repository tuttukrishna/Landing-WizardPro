'use client';

import { useState, useEffect, useCallback } from 'react';
import { storageGet, storageSet, storageRemove } from '@/utils';
import { STORAGE_KEYS } from '@/constants';

interface AuthUser {
  id: string;
  name: string;
  handle: string;
  email: string;
  avatarColor?: string;
}

/**
 * useAuth
 * ───────
 * Manages the current user session.
 * Persists to localStorage using the wp_user key (same as original app).
 */
export function useAuth() {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = storageGet<AuthUser | null>(STORAGE_KEYS.USER, null);
    setUser(stored);
    setLoading(false);
  }, []);

  const login = useCallback((userData: Omit<AuthUser, 'id'>) => {
    const u: AuthUser = {
      ...userData,
      id: userData.handle.replace('@', ''),
      avatarColor: 'var(--accent)',
    };
    setUser(u);
    storageSet(STORAGE_KEYS.USER, u);
    // Sync with original app's class-based auth
    if (typeof document !== 'undefined') {
      document.documentElement.classList.add('wizard-app-boot');
      document.body.classList.add('wizard-app-active');
    }
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    storageRemove(STORAGE_KEYS.USER);
    if (typeof document !== 'undefined') {
      document.documentElement.classList.remove('wizard-app-boot');
      document.body.classList.remove('wizard-app-active');
    }
  }, []);

  return { user, loading, login, logout, isLoggedIn: user !== null };
}
