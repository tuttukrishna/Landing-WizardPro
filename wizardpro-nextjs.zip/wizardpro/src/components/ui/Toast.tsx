'use client';

import { useEffect, useState } from 'react';

interface ToastProps {
  message: string;
  visible: boolean;
  duration?: number;
  onHide: () => void;
}

export default function Toast({ message, visible, duration = 2500, onHide }: ToastProps) {
  useEffect(() => {
    if (!visible) return;
    const id = setTimeout(onHide, duration);
    return () => clearTimeout(id);
  }, [visible, duration, onHide]);

  return (
    <div className={`toast${visible ? ' show' : ''}`}>
      {message}
    </div>
  );
}

// ── Hook ──────────────────────────────────────────────────────────────────────
export function useToast() {
  const [state, setState] = useState({ message: '', visible: false });

  const showToast = (message: string) => {
    setState({ message, visible: true });
  };

  const hideToast = () => {
    setState((s) => ({ ...s, visible: false }));
  };

  return { toastMessage: state.message, toastVisible: state.visible, showToast, hideToast };
}
