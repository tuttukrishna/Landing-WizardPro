/**
 * marketService
 * ─────────────
 * Abstraction layer for market data fetching.
 * Currently returns demo/static data.
 * Replace the fetch calls with real API endpoints for production.
 *
 * Suggested APIs:
 *   - NSE India: https://nseindia.com (unofficial endpoints)
 *   - Yahoo Finance: https://query1.finance.yahoo.com/v8/finance/chart/{symbol}
 *   - Alpha Vantage: https://www.alphavantage.co (free tier)
 */

export interface QuoteData {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePct: number;
  volume: number;
  exchange: 'NSE' | 'BSE';
}

/**
 * Get a quote for a single symbol.
 * In production, replace with a real API call.
 */
export async function getQuote(symbol: string): Promise<QuoteData> {
  // Demo data — replace with real fetch
  await new Promise((r) => setTimeout(r, 400)); // simulate latency

  const seed = symbol.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0);
  const price = 100 + (seed % 4900);
  const pctRaw = ((seed % 700) - 350) / 100;

  return {
    symbol,
    name: symbol + ' Ltd',
    price: parseFloat(price.toFixed(2)),
    change: parseFloat(((price * pctRaw) / 100).toFixed(2)),
    changePct: parseFloat(pctRaw.toFixed(2)),
    volume: (seed % 5000000) + 100000,
    exchange: seed % 2 === 0 ? 'NSE' : 'BSE',
  };
}

/**
 * Search for stocks by query string.
 */
export async function searchStocks(query: string): Promise<{ symbol: string; name: string; exchange: 'NSE' | 'BSE' }[]> {
  // Demo universe
  const UNIVERSE = [
    { symbol: 'RELIANCE', name: 'Reliance Industries', exchange: 'NSE' as const },
    { symbol: 'TCS', name: 'Tata Consultancy Services', exchange: 'NSE' as const },
    { symbol: 'HDFCBANK', name: 'HDFC Bank', exchange: 'NSE' as const },
    { symbol: 'INFY', name: 'Infosys', exchange: 'NSE' as const },
    { symbol: 'ICICIBANK', name: 'ICICI Bank', exchange: 'NSE' as const },
    { symbol: 'SBIN', name: 'State Bank of India', exchange: 'NSE' as const },
    { symbol: 'BHARTIARTL', name: 'Bharti Airtel', exchange: 'NSE' as const },
    { symbol: 'BAJFINANCE', name: 'Bajaj Finance', exchange: 'NSE' as const },
    { symbol: 'MARUTI', name: 'Maruti Suzuki', exchange: 'NSE' as const },
    { symbol: 'HAL', name: 'Hindustan Aeronautics', exchange: 'NSE' as const },
    { symbol: 'BEL', name: 'Bharat Electronics', exchange: 'NSE' as const },
    { symbol: 'TATAMOTORS', name: 'Tata Motors', exchange: 'NSE' as const },
    { symbol: 'WIPRO', name: 'Wipro', exchange: 'NSE' as const },
    { symbol: 'ADANIENT', name: 'Adani Enterprises', exchange: 'NSE' as const },
    { symbol: 'LT', name: 'Larsen & Toubro', exchange: 'NSE' as const },
    { symbol: 'AXISBANK', name: 'Axis Bank', exchange: 'NSE' as const },
    { symbol: 'ONGC', name: 'Oil & Natural Gas Corp', exchange: 'NSE' as const },
    { symbol: 'NTPC', name: 'NTPC', exchange: 'NSE' as const },
    { symbol: 'POWERGRID', name: 'Power Grid Corp', exchange: 'NSE' as const },
    { symbol: 'KOTAKBANK', name: 'Kotak Mahindra Bank', exchange: 'NSE' as const },
  ];

  const q = query.toLowerCase();
  return UNIVERSE.filter(
    (s) => s.symbol.toLowerCase().includes(q) || s.name.toLowerCase().includes(q)
  ).slice(0, 8);
}
