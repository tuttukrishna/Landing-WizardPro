'use client';

import { useState, useCallback } from 'react';
import type { Post, PostTag } from '@/types';
import { generateId } from '@/utils';

/**
 * usePosts
 * ────────
 * Manages the community feed post state.
 * In production connect to a real-time backend (Supabase, Firebase, etc.)
 */
export function usePosts(initialPosts: Post[] = []) {
  const [posts, setPosts] = useState<Post[]>(initialPosts);

  const addPost = useCallback(
    (content: string, tag: PostTag | undefined, author: { name: string; handle: string; avatarColor?: string }) => {
      const newPost: Post = {
        id: Date.now(),
        user: author.name,
        handle: author.handle,
        avatarColor: author.avatarColor ?? 'var(--accent)',
        tag,
        likes: 0,
        comments: 0,
        time: 'Just now',
        content,
      };
      setPosts((prev) => [newPost, ...prev]);
      return newPost;
    },
    []
  );

  const toggleLike = useCallback((postId: number | string) => {
    setPosts((prev) =>
      prev.map((p) => {
        if (p.id !== postId) return p;
        const liked = !p.liked;
        return { ...p, liked, likes: liked ? p.likes + 1 : p.likes - 1 };
      })
    );
  }, []);

  const toggleBookmark = useCallback((postId: number | string) => {
    setPosts((prev) =>
      prev.map((p) =>
        p.id === postId ? { ...p, bookmarked: !p.bookmarked } : p
      )
    );
  }, []);

  const addComment = useCallback((postId: number | string) => {
    setPosts((prev) =>
      prev.map((p) =>
        p.id === postId ? { ...p, comments: p.comments + 1 } : p
      )
    );
  }, []);

  const deletePost = useCallback((postId: number | string) => {
    setPosts((prev) => prev.filter((p) => p.id !== postId));
  }, []);

  return { posts, addPost, toggleLike, toggleBookmark, addComment, deletePost };
}
