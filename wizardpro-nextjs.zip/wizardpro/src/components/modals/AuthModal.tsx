'use client';

import { useState } from 'react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: (user: { name: string; handle: string; email: string }) => void;
}

type AuthTab = 'login' | 'signup';

export default function AuthModal({ isOpen, onClose, onSuccess }: AuthModalProps) {
  const [tab, setTab] = useState<AuthTab>('signup');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = () => {
    setError('');
    if (!email || !password) { setError('Please fill all fields'); return; }
    if (tab === 'signup' && !name) { setError('Please enter your name'); return; }

    const handle = '@' + (name || email.split('@')[0]).toLowerCase().replace(/\s+/g, '');
    onSuccess?.({ name: name || email.split('@')[0], handle, email });
    onClose();
  };

  return (
    <div className="auth-overlay" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="auth-card">
        <div className="auth-logo-mark">
          <span style={{ fontFamily: 'Archivo Black, sans-serif', fontSize: 22, color: '#E8571A', fontWeight: 800 }}>W</span>
        </div>
        <div className="auth-title">WizardPRO</div>
        <div className="auth-sub">Your expert analyst on the go</div>

        <div className="auth-tabs">
          <div className={`auth-tab${tab === 'signup' ? ' active' : ''}`} onClick={() => setTab('signup')}>Sign Up</div>
          <div className={`auth-tab${tab === 'login' ? ' active' : ''}`} onClick={() => setTab('login')}>Log In</div>
        </div>

        {tab === 'signup' && (
          <div className="auth-field">
            <label>Name</label>
            <input
              type="text"
              placeholder="Your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoComplete="name"
            />
          </div>
        )}

        <div className="auth-field">
          <label>Email</label>
          <input
            type="email"
            placeholder="you@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="email"
          />
        </div>

        <div className="auth-field">
          <label>Password</label>
          <input
            type="password"
            placeholder="••••••••"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete={tab === 'signup' ? 'new-password' : 'current-password'}
          />
        </div>

        {error && (
          <div style={{ color: 'var(--red)', fontSize: 12, marginBottom: 8, textAlign: 'center' }}>{error}</div>
        )}

        <button className="auth-btn" onClick={handleSubmit}>
          {tab === 'signup' ? 'Create Account' : 'Log In'}
        </button>

        <div className="auth-divider">or</div>

        <button className="social-btn" onClick={handleSubmit}>
          <svg width="18" height="18" viewBox="0 0 48 48">
            <path fill="#FFC107" d="M43.6 20H24v8h11.3C33.7 33.6 29.3 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3 0 5.8 1.1 7.9 3l5.7-5.7C34.1 6.5 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.7-.4-4z"/>
            <path fill="#FF3D00" d="m6.3 14.7 6.6 4.8C14.5 15.6 18.9 12 24 12c3 0 5.8 1.1 7.9 3l5.7-5.7C34.1 6.5 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/>
            <path fill="#4CAF50" d="M24 44c5.2 0 9.9-1.9 13.5-5l-6.2-5.2C29.4 35.6 26.8 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.6 5.1C9.7 39.6 16.3 44 24 44z"/>
            <path fill="#1976D2" d="M43.6 20H24v8h11.3c-.8 2.2-2.2 4-4.1 5.2l6.2 5.2C40.9 35.2 44 30 44 24c0-1.3-.1-2.7-.4-4z"/>
          </svg>
          Continue with Google
        </button>

        <div className="auth-skip" onClick={onClose}>Skip for now →</div>
      </div>
    </div>
  );
}
