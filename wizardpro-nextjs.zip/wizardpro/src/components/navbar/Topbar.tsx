'use client';

import { useEffect, useState } from 'react';

interface TopbarProps {
  onProfile?: () => void;
  onMessages?: () => void;
  onNotifications?: () => void;
}

/**
 * Topbar
 * ──────
 * Fixed top navigation bar shown inside the app shell (after login).
 * Shows the WizardPRO logo, current time, market status pill,
 * messages, notifications, and profile button.
 */
export default function Topbar({
  onProfile,
  onMessages,
  onNotifications,
}: TopbarProps) {
  const [time, setTime] = useState('');
  const [marketStatus, setMarketStatus] = useState('Pre-Market');

  useEffect(() => {
    const update = () => {
      const now = new Date();
      const hh = now.getHours().toString().padStart(2, '0');
      const mm = now.getMinutes().toString().padStart(2, '0');
      setTime(`${hh}:${mm}`);

      const h = now.getHours();
      const m = now.getMinutes();
      const total = h * 60 + m;
      if (total >= 9 * 60 + 15 && total < 15 * 60 + 30) {
        setMarketStatus('Market Open');
      } else if (total >= 9 * 60 && total < 9 * 60 + 15) {
        setMarketStatus('Pre-Open');
      } else {
        setMarketStatus('Market Closed');
      }
    };
    update();
    const id = setInterval(update, 60_000);
    return () => clearInterval(id);
  }, []);

  return (
    <header className="topbar">
      <div className="topbar__logo">
        <div
          className="topbar__logo-mark"
          style={{ background: 'transparent', padding: 0, overflow: 'hidden' }}
        >
          {/* Logo mark — fallback text if image fails */}
          <span style={{ fontFamily: 'var(--ff)', fontWeight: 800, fontSize: 16 }}>
            W
          </span>
        </div>
        WizardPRO
      </div>

      <div className="topbar__right">
        <div className="topbar__time">{time}</div>

        <div className="market-pill" id="marketPill">
          <span className="dot" />
          <span id="marketStatus">{marketStatus}</span>
        </div>

        <div className="topbar__social">
          <button
            className="icon-btn"
            onClick={onMessages}
            title="Messages"
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth={2}
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M22 2 11 13" />
              <path d="m22 2-7 20-4-9-9-4Z" />
            </svg>
          </button>

          <button
            className="icon-btn"
            onClick={onNotifications}
            title="Notifications"
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth={2}
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M15 17h5l-1.4-1.4a2 2 0 0 1-.6-1.4V11a6 6 0 1 0-12 0v3.2a2 2 0 0 1-.6 1.4L4 17h5" />
              <path d="M10 21a2 2 0 0 0 4 0" />
            </svg>
          </button>
        </div>

        <button
          className="icon-btn"
          onClick={onProfile}
          title="Profile"
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth={2}
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <circle cx={12} cy={8} r={4} />
            <path d="M6 20v-1a6 6 0 0 1 12 0v1" />
          </svg>
        </button>
      </div>
    </header>
  );
}
