'use client';

import { useState } from 'react';
import type { Post } from '@/types';

const TAG_CLASSES: Record<string, string> = {
  bull: 'tag-bull',
  bear: 'tag-bear',
  options: 'tag-options',
  macro: 'tag-macro',
  news: 'tag-news',
};

const TAG_LABELS: Record<string, string> = {
  bull: '⚡ Intraday',
  bear: '📈 Swing',
  options: '⎔ F&O',
  macro: '🪙 Commodities',
  news: '◉ News',
};

interface PostCardProps {
  post: Post;
  onLike?: (id: number | string) => void;
  onComment?: (id: number | string) => void;
  onRepost?: (id: number | string) => void;
  onBookmark?: (id: number | string) => void;
  onAvatarClick?: (handle: string) => void;
  onCardClick?: (id: number | string) => void;
}

export default function PostCard({
  post,
  onLike,
  onComment,
  onRepost,
  onBookmark,
  onAvatarClick,
  onCardClick,
}: PostCardProps) {
  const [liked, setLiked] = useState(post.liked ?? false);
  const [likeCount, setLikeCount] = useState(post.likes);
  const [bookmarked, setBookmarked] = useState(post.bookmarked ?? false);

  const handleLike = (e: React.MouseEvent) => {
    e.stopPropagation();
    setLiked((v) => !v);
    setLikeCount((c) => (liked ? c - 1 : c + 1));
    onLike?.(post.id);
  };

  const handleBookmark = (e: React.MouseEvent) => {
    e.stopPropagation();
    setBookmarked((v) => !v);
    onBookmark?.(post.id);
  };

  return (
    <div
      className="post-card"
      data-tag={post.tag ?? ''}
      data-post-id={post.id}
      onClick={() => onCardClick?.(post.id)}
    >
      {post.repostedBy && (
        <div className="repost-banner">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" style={{ width: 12, height: 12 }}>
            <path d="M17 1l4 4-4 4" /><path d="M3 11V9a4 4 0 0 1 4-4h14" />
            <path d="M7 23l-4-4 4-4" /><path d="M21 13v2a4 4 0 0 1-4 4H3" />
          </svg>
          Reposted by {post.repostedBy}
        </div>
      )}

      {/* Header */}
      <div
        className="post-header"
        style={{ cursor: onAvatarClick ? 'pointer' : 'default' }}
        onClick={(e) => {
          e.stopPropagation();
          onAvatarClick?.(post.handle);
        }}
      >
        <div className="avatar" style={{ background: post.avatarColor ?? 'var(--accent)' }} />
        <div className="post-meta">
          <div className="post-name">{post.user}</div>
          <div className="post-handle">{post.handle}</div>
        </div>
        {post.tag && (
          <span className={`post-tag ${TAG_CLASSES[post.tag] ?? ''}`}>
            {TAG_LABELS[post.tag] ?? post.tag}
          </span>
        )}
      </div>

      {/* Image */}
      {post.image && (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={post.image}
          className="post-image"
          onClick={(e) => e.stopPropagation()}
          loading="lazy"
          alt=""
        />
      )}

      {/* Chart preview */}
      {post.chart && (
        <div className="chart-preview">
          <svg className="chart-svg" viewBox="0 0 300 60" preserveAspectRatio="none">
            <polyline
              points="0,50 30,45 60,40 90,42 120,35 150,28 180,32 210,22 240,18 270,24 300,15"
              fill="none"
              stroke="var(--red)"
              strokeWidth={1.5}
            />
            <polygon
              points="0,60 0,50 30,45 60,40 90,42 120,35 150,28 180,32 210,22 240,18 270,24 300,15 300,60"
              fill="var(--red-lt)"
              opacity={0.5}
            />
          </svg>
        </div>
      )}

      {/* Body */}
      <div
        className="post-body"
        dangerouslySetInnerHTML={{ __html: post.content }}
      />

      {/* Actions */}
      <div className="post-actions">
        <span
          className={`post-action${liked ? ' liked' : ''}`}
          onClick={handleLike}
        >
          <svg viewBox="0 0 24 24" fill={liked ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth={2} strokeLinecap="round">
            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
          </svg>
          {likeCount}
        </span>

        <span
          className="post-action"
          onClick={(e) => { e.stopPropagation(); onComment?.(post.id); }}
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
          </svg>
          {post.comments}
        </span>

        <span
          className="post-action"
          onClick={(e) => { e.stopPropagation(); onRepost?.(post.id); }}
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round">
            <path d="M17 1l4 4-4 4" /><path d="M3 11V9a4 4 0 0 1 4-4h14" />
            <path d="M7 23l-4-4 4-4" /><path d="M21 13v2a4 4 0 0 1-4 4H3" />
          </svg>
        </span>

        <span
          className={`post-action${bookmarked ? ' bookmarked' : ''}`}
          onClick={handleBookmark}
        >
          <svg viewBox="0 0 24 24" fill={bookmarked ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth={2} strokeLinecap="round">
            <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" />
          </svg>
        </span>

        <span className="post-time">{post.time}</span>
      </div>
    </div>
  );
}
