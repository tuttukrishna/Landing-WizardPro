/**
 * authService
 * ───────────
 * Authentication service layer.
 * Currently uses localStorage-based mock auth (matching the original app).
 * Replace with Supabase Auth / Firebase Auth / NextAuth for production.
 */

import { storageGet, storageSet, storageRemove } from '@/utils';
import { STORAGE_KEYS } from '@/constants';

export interface AuthUser {
  id: string;
  name: string;
  handle: string;
  email: string;
  avatarColor?: string;
  createdAt?: string;
}

/**
 * Get the currently logged-in user from storage.
 */
export function getCurrentUser(): AuthUser | null {
  return storageGet<AuthUser | null>(STORAGE_KEYS.USER, null);
}

/**
 * Sign in / sign up with email + password (mock).
 */
export async function signInWithEmail(
  email: string,
  password: string,
  name?: string
): Promise<AuthUser> {
  // Simulate network delay
  await new Promise((r) => setTimeout(r, 500));

  const displayName = name || email.split('@')[0];
  const handle = '@' + displayName.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '');

  const user: AuthUser = {
    id: handle.replace('@', ''),
    name: displayName,
    handle,
    email,
    avatarColor: 'var(--accent)',
    createdAt: new Date().toISOString(),
  };

  storageSet(STORAGE_KEYS.USER, user);
  return user;
}

/**
 * Sign out the current user.
 */
export async function signOut(): Promise<void> {
  storageRemove(STORAGE_KEYS.USER);
}

/**
 * Check if user is authenticated.
 */
export function isAuthenticated(): boolean {
  return getCurrentUser() !== null;
}
