// ─── App Meta ────────────────────────────────────────────────────────────────

export const APP_NAME = 'WizardPRO';
export const APP_TAGLINE = 'Your expert analyst on the go';
export const APP_COMPANY = 'OpenFi.Ltd';
export const APP_YEAR = '2026';
export const THEME_COLOR = '#E8571A';

// ─── Navigation Tabs ─────────────────────────────────────────────────────────

export const NAV_TABS = [
  { id: 'community', label: 'Community' },
  { id: 'fundamental', label: 'Fundamental' },
  { id: 'tradelab', label: 'TradeLab' },
  { id: 'news', label: 'News' },
] as const;

// ─── Post Tags ───────────────────────────────────────────────────────────────

export const TAG_CLASSES: Record<string, string> = {
  bull: 'tag-bull',
  bear: 'tag-bear',
  options: 'tag-options',
  macro: 'tag-macro',
  news: 'tag-news',
};

export const TAG_LABELS: Record<string, string> = {
  bull: '⚡ Intraday',
  bear: '📈 Swing',
  options: '⎔ F&O',
  macro: '🪙 Commodities',
  news: '◉ News',
};

// ─── Subscription Plans ──────────────────────────────────────────────────────

export const PLANS = [
  {
    name: 'Essential',
    monthlyPrice: '₹199',
    features: [
      'Premium paper trading lab',
      'Community access',
      'Daily pre-market report',
      'News',
    ],
    featured: false,
  },
  {
    name: 'Premium',
    monthlyPrice: '₹399',
    features: [
      'Premium paper trading lab',
      'Community access',
      'Daily pre-market report',
      'News',
      'Fundamental analysis tool',
      'Alert setting',
      'Copy trading',
      'Position sizing calculator',
    ],
    featured: true,
  },
] as const;

// ─── Market Data (Static Demo) ────────────────────────────────────────────────

export const MARKET_INDICES = [
  { name: 'NIFTY 50', value: '22,647', change: '+143', changePct: '+0.64%', isUp: true },
  { name: 'BANK NIFTY', value: '48,921', change: '+312', changePct: '+0.64%', isUp: true },
  { name: 'SENSEX', value: '74,572', change: '+481', changePct: '+0.65%', isUp: true },
  { name: 'NIFTY IT', value: '38,104', change: '-187', changePct: '-0.49%', isUp: false },
] as const;

export const SECTOR_DATA = [
  { name: 'Banking', change: 1.24, isUp: true },
  { name: 'IT', change: -0.48, isUp: false },
  { name: 'FMCG', change: 0.72, isUp: true },
  { name: 'Auto', change: 1.86, isUp: true },
  { name: 'Pharma', change: -0.21, isUp: false },
  { name: 'Metals', change: 2.14, isUp: true },
] as const;

// ─── Fundamental Tool Tabs ────────────────────────────────────────────────────

export const FUND_TABS = [
  { id: 'overview', label: '🌐 Overview' },
  { id: 'analysis', label: '📊 Analysis' },
  { id: 'report', label: '📄 Report' },
  { id: 'screener', label: '🔍 Screener' },
] as const;

// ─── Storage Keys ─────────────────────────────────────────────────────────────

export const STORAGE_KEYS = {
  USER: 'wp_user',
  SETTINGS: 'wp_settings',
  POSTS: 'wp_posts',
  JOURNAL: 'wp_journal',
  POSITIONS: 'wp_positions',
  ORDERS: 'wp_orders',
  WATCHLIST: 'wp_watchlist',
  BALANCE: 'wp_balance',
} as const;

// ─── Default Paper Trading Balance ───────────────────────────────────────────

export const DEFAULT_PAPER_BALANCE = 500000;
