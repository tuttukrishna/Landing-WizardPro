import WizardApp from '@/components/WizardApp';

export default function DashboardPage() {
  return <WizardApp />;
}
