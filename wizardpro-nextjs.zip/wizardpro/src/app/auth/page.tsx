import WizardApp from '@/components/WizardApp';

export default function AuthPage() {
  return <WizardApp />;
}
