'use client';

import { useState } from 'react';

interface LikeButtonProps {
  count: number;
  liked?: boolean;
  onToggle?: (liked: boolean) => void;
}

export default function LikeButton({ count, liked: initialLiked = false, onToggle }: LikeButtonProps) {
  const [liked, setLiked] = useState(initialLiked);
  const [localCount, setLocalCount] = useState(count);

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    const next = !liked;
    setLiked(next);
    setLocalCount((c) => (next ? c + 1 : c - 1));
    onToggle?.(next);
  };

  return (
    <span
      className={`post-action${liked ? ' liked' : ''}`}
      onClick={handleClick}
      style={{ cursor: 'pointer' }}
    >
      <svg
        viewBox="0 0 24 24"
        fill={liked ? 'currentColor' : 'none'}
        stroke="currentColor"
        strokeWidth={2}
        strokeLinecap="round"
      >
        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
      </svg>
      {localCount}
    </span>
  );
}
