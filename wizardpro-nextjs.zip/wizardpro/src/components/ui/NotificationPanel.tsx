'use client';

import type { Notification } from '@/types';

interface NotificationPanelProps {
  isOpen: boolean;
  notifications: Notification[];
  onClose: () => void;
  onMarkAllRead?: () => void;
}

const TYPE_ICONS: Record<string, string> = {
  like: '❤️',
  follow: '👤',
  comment: '💬',
  mention: '@',
  trade: '📈',
};

export default function NotificationPanel({
  isOpen,
  notifications,
  onClose,
  onMarkAllRead,
}: NotificationPanelProps) {
  if (!isOpen) return null;

  const unread = notifications.filter((n) => !n.read).length;

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 600,
        background: 'rgba(0,0,0,0.5)',
        backdropFilter: 'blur(4px)',
      }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div
        style={{
          position: 'absolute',
          top: 60,
          right: 12,
          width: 'min(360px, calc(100vw - 24px))',
          maxHeight: '70vh',
          overflowY: 'auto',
          background: 'var(--bg2)',
          border: '1px solid var(--border)',
          borderRadius: 16,
          boxShadow: 'var(--shadow-lg)',
        }}
      >
        {/* Header */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '14px 16px',
          borderBottom: '1px solid var(--border)',
          position: 'sticky',
          top: 0,
          background: 'var(--bg2)',
        }}>
          <span style={{ fontWeight: 800, fontSize: 15 }}>
            Notifications {unread > 0 && <span style={{ color: 'var(--accent)', fontSize: 13 }}>({unread})</span>}
          </span>
          <div style={{ display: 'flex', gap: 10 }}>
            {unread > 0 && (
              <button
                onClick={onMarkAllRead}
                style={{ background: 'none', border: 'none', color: 'var(--accent)', fontSize: 12, cursor: 'pointer', fontWeight: 600 }}
              >
                Mark all read
              </button>
            )}
            <button
              onClick={onClose}
              style={{ background: 'none', border: 'none', color: 'var(--text3)', fontSize: 18, cursor: 'pointer', lineHeight: 1 }}
            >
              ×
            </button>
          </div>
        </div>

        {/* List */}
        {notifications.length === 0 ? (
          <div style={{ padding: 32, textAlign: 'center', color: 'var(--text3)', fontSize: 13 }}>
            No notifications yet
          </div>
        ) : (
          notifications.map((n) => (
            <div
              key={n.id}
              style={{
                display: 'flex',
                gap: 12,
                padding: '12px 16px',
                borderBottom: '1px solid var(--border)',
                background: n.read ? 'transparent' : 'var(--accent-dim)',
                cursor: 'pointer',
              }}
            >
              <div style={{
                width: 36, height: 36, borderRadius: '50%',
                background: 'var(--bg3)', display: 'flex',
                alignItems: 'center', justifyContent: 'center',
                fontSize: 16, flexShrink: 0,
              }}>
                {TYPE_ICONS[n.type] ?? '🔔'}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, color: 'var(--text)', lineHeight: 1.5 }}>{n.message}</div>
                <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 2 }}>{n.timestamp}</div>
              </div>
              {!n.read && (
                <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--accent)', flexShrink: 0, marginTop: 4 }} />
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
