import WizardApp from '@/components/WizardApp';

// Profile route — renders full app and lets JS navigate to profile view
export default function ProfilePage() {
  return <WizardApp />;
}
