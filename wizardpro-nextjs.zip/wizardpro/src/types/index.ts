// ─── User & Auth ────────────────────────────────────────────────────────────

export interface User {
  id: string;
  name: string;
  handle: string;
  avatar?: string;
  avatarColor?: string;
  bio?: string;
  followers?: number;
  following?: number;
  posts?: number;
  winRate?: string;
  pnl?: string;
  trades?: number;
  tradingStyle?: string;
  experience?: string;
  favSector?: string;
  demoTrades?: Trade[];
}

// ─── Posts & Feed ───────────────────────────────────────────────────────────

export type PostTag = 'bull' | 'bear' | 'options' | 'macro' | 'news';

export interface Post {
  id: number | string;
  user: string;
  handle: string;
  avatar?: string;
  avatarColor?: string;
  tag?: PostTag;
  likes: number;
  comments: number;
  time: string;
  content: string;
  image?: string;
  chart?: boolean;
  repostedBy?: string;
  liked?: boolean;
  bookmarked?: boolean;
}

// ─── Trading / Journal ──────────────────────────────────────────────────────

export interface Trade {
  sym: string;
  type: 'long' | 'short' | 'options';
  date: string;
  status: 'open' | 'closed';
  pnl: string;
  entry: string;
  exit: string;
}

export interface JournalEntry {
  id: string;
  symbol: string;
  date: string;
  type: 'long' | 'short';
  entry: number;
  exit: number;
  quantity: number;
  pnl: number;
  notes?: string;
}

export interface Order {
  symbol: string;
  side: 'buy' | 'sell';
  type: 'market' | 'limit';
  quantity: number;
  price: number;
  status: 'pending' | 'filled' | 'cancelled';
}

export interface Position {
  symbol: string;
  quantity: number;
  avgPrice: number;
  ltp: number;
  pnl: number;
  pnlPct: number;
}

// ─── Market Data ────────────────────────────────────────────────────────────

export interface MarketIndex {
  name: string;
  value: string;
  change: string;
  changePct: string;
  isUp: boolean;
}

export interface SectorData {
  name: string;
  change: number;
  isUp: boolean;
}

export interface WatchlistItem {
  ticker: string;
  name: string;
  price: string;
  change: string;
  isUp: boolean;
}

// ─── Messaging ──────────────────────────────────────────────────────────────

export interface Message {
  id: string;
  senderId: string;
  text: string;
  timestamp: string;
  read: boolean;
}

export interface Thread {
  id: string;
  userId: string;
  userName: string;
  userHandle: string;
  lastMessage: string;
  timestamp: string;
  unread: number;
}

// ─── Notifications ──────────────────────────────────────────────────────────

export interface Notification {
  id: string;
  type: 'like' | 'follow' | 'comment' | 'mention' | 'trade';
  userId?: string;
  userName?: string;
  message: string;
  timestamp: string;
  read: boolean;
}

// ─── Navigation ─────────────────────────────────────────────────────────────

export type AppPage = 'page-home' | 'page-sub' | 'page-signin';
export type AppTab = 'community' | 'fundamental' | 'tradelab' | 'news';

export interface NavTab {
  id: AppTab;
  label: string;
  icon: string;
}

// ─── Fundamental Analysis ───────────────────────────────────────────────────

export interface StockFundamentals {
  ticker: string;
  name: string;
  exchange: 'NSE' | 'BSE';
  sector: string;
  price: number;
  change: number;
  changePct: number;
  marketCap: string;
  peRatio: number;
  pbRatio: number;
  roe: number;
  roce: number;
  debtToEquity: number;
  revenue: string;
  netProfit: string;
  eps: number;
  dividendYield: number;
  score: number;
  recommendation: 'buy' | 'sell' | 'hold';
}

// ─── Settings ───────────────────────────────────────────────────────────────

export interface AppSettings {
  theme: 'dark' | 'light';
  notifications: boolean;
  soundAlerts: boolean;
  marketHours: boolean;
}
