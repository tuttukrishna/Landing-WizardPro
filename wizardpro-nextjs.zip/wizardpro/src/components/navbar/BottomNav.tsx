'use client';

import { useCallback } from 'react';

export type TabId = 'community' | 'fundamental' | 'tradelab' | 'news';

interface NavItem {
  id: TabId;
  label: string;
  icon: React.ReactNode;
}

interface BottomNavProps {
  activeTab: TabId;
  onTabChange: (tab: TabId) => void;
}

const CommunityIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} strokeLinecap="round" strokeLinejoin="round">
    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
    <circle cx="9" cy="7" r="4"/>
    <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
    <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
  </svg>
);

const FundamentalIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} strokeLinecap="round" strokeLinejoin="round">
    <line x1="18" y1="20" x2="18" y2="10"/>
    <line x1="12" y1="20" x2="12" y2="4"/>
    <line x1="6" y1="20" x2="6" y2="14"/>
  </svg>
);

const TradeLabIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} strokeLinecap="round" strokeLinejoin="round">
    <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
  </svg>
);

const NewsIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.75} strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-2 2Zm0 0a2 2 0 0 1-2-2v-9c0-1.1.9-2 2-2h2"/>
    <path d="M18 14h-8"/><path d="M15 18h-5"/><path d="M10 6h8v4h-8V6Z"/>
  </svg>
);

const NAV_ITEMS: NavItem[] = [
  { id: 'community',   label: 'Community',   icon: <CommunityIcon /> },
  { id: 'fundamental', label: 'Fundamental', icon: <FundamentalIcon /> },
  { id: 'tradelab',   label: 'TradeLab',    icon: <TradeLabIcon /> },
  { id: 'news',       label: 'News',        icon: <NewsIcon /> },
];

/**
 * BottomNav
 * ─────────
 * The floating pill navigation bar fixed at the bottom of the screen.
 * Active tab expands with a gradient pill and animated label.
 */
export default function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  const handleClick = useCallback(
    (id: TabId) => {
      onTabChange(id);
    },
    [onTabChange]
  );

  return (
    <nav className="bottom-nav">
      <div className="bnav-pill-wrap">
        {NAV_ITEMS.map(({ id, label, icon }) => (
          <button
            key={id}
            className={`bnav-btn${activeTab === id ? ' active' : ''}`}
            onClick={() => handleClick(id)}
            aria-label={label}
          >
            <span className="bnav-icon">{icon}</span>
            <span className="bnav-label">{label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
}
