'use client';

import { useEffect, useRef } from 'react';
import APP_HTML from '@/lib/appHtml';

/**
 * WizardApp
 * ─────────
 * Client component that injects the complete WizardPRO HTML markup and
 * then loads the application JavaScript bundle. All existing UI, interactions,
 * animations, modals, routing, and state behaviour are preserved identically.
 */
export default function WizardApp() {
  const scriptsLoaded = useRef(false);

  useEffect(() => {
    if (scriptsLoaded.current) return;
    scriptsLoaded.current = true;

    const script = document.createElement('script');
    script.src = '/app-scripts.js';
    script.async = false;
    script.onload = () => {
      // Dispatch DOMContentLoaded equivalent so any listeners fire
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new Event('app-scripts-loaded'));
      }
    };
    document.body.appendChild(script);

    return () => {
      // Cleanup on unmount (dev hot-reload)
      const existing = document.querySelector('script[src="/app-scripts.js"]');
      if (existing) existing.remove();
    };
  }, []);

  return (
    <div
      id="wizardpro-root"
      dangerouslySetInnerHTML={{ __html: APP_HTML }}
    />
  );
}
