'use client';

import { useState } from 'react';
import type { AppSettings } from '@/types';

interface SettingsPanelProps {
  isOpen: boolean;
  settings: AppSettings;
  onClose: () => void;
  onSave: (settings: AppSettings) => void;
  onLogout?: () => void;
}

export default function SettingsPanel({
  isOpen,
  settings: initialSettings,
  onClose,
  onSave,
  onLogout,
}: SettingsPanelProps) {
  const [settings, setSettings] = useState<AppSettings>(initialSettings);

  if (!isOpen) return null;

  const toggle = (key: keyof AppSettings) => {
    if (key === 'theme') return;
    setSettings((s) => ({ ...s, [key]: !s[key] }));
  };

  return (
    <div
      style={{
        position: 'fixed', inset: 0, zIndex: 700,
        background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(8px)',
      }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div
        style={{
          position: 'absolute', bottom: 0, left: 0, right: 0,
          maxWidth: 600, margin: '0 auto',
          background: 'var(--bg2)', borderRadius: '20px 20px 0 0',
          padding: '20px 18px 40px',
          maxHeight: '85vh', overflowY: 'auto',
        }}
      >
        <div style={{ width: 36, height: 4, borderRadius: 2, background: 'var(--border)', margin: '0 auto 20px' }} />

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <span style={{ fontWeight: 800, fontSize: 17 }}>Settings</span>
          <button onClick={onClose} style={{ background: 'none', border: 'none', fontSize: 20, cursor: 'pointer', color: 'var(--text3)' }}>×</button>
        </div>

        {/* Settings rows */}
        {[
          { key: 'notifications' as const, label: 'Push Notifications', icon: '🔔' },
          { key: 'soundAlerts' as const, label: 'Sound Alerts', icon: '🔊' },
          { key: 'marketHours' as const, label: 'Market Hours Alerts', icon: '⏰' },
        ].map(({ key, label, icon }) => (
          <div
            key={key}
            style={{
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              padding: '14px 0', borderBottom: '1px solid var(--border)',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ fontSize: 18 }}>{icon}</span>
              <span style={{ fontSize: 14, color: 'var(--text)' }}>{label}</span>
            </div>
            <div
              onClick={() => toggle(key)}
              style={{
                width: 44, height: 24, borderRadius: 12,
                background: settings[key] ? 'var(--accent)' : 'var(--bg4)',
                position: 'relative', cursor: 'pointer', transition: 'background 0.2s',
              }}
            >
              <div style={{
                position: 'absolute', top: 2, left: settings[key] ? 22 : 2,
                width: 20, height: 20, borderRadius: '50%', background: '#fff',
                transition: 'left 0.2s', boxShadow: '0 1px 4px rgba(0,0,0,0.3)',
              }} />
            </div>
          </div>
        ))}

        {/* Theme */}
        <div style={{ padding: '14px 0', borderBottom: '1px solid var(--border)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
            <span style={{ fontSize: 18 }}>🎨</span>
            <span style={{ fontSize: 14, color: 'var(--text)' }}>Theme</span>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            {(['dark', 'light'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setSettings((s) => ({ ...s, theme: t }))}
                style={{
                  flex: 1, padding: '8px', borderRadius: 8, fontSize: 13, fontWeight: 600,
                  cursor: 'pointer',
                  background: settings.theme === t ? 'var(--accent)' : 'var(--bg3)',
                  color: settings.theme === t ? '#fff' : 'var(--text2)',
                  border: '1px solid var(--border)',
                }}
              >
                {t.charAt(0).toUpperCase() + t.slice(1)}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={() => { onSave(settings); onClose(); }}
          style={{
            width: '100%', padding: 14, borderRadius: 12, marginTop: 20,
            background: 'var(--accent)', color: '#fff', fontSize: 14, fontWeight: 700,
            border: 'none', cursor: 'pointer',
          }}
        >
          Save Settings
        </button>

        {onLogout && (
          <button
            onClick={() => { onLogout(); onClose(); }}
            style={{
              width: '100%', padding: 14, borderRadius: 12, marginTop: 10,
              background: 'none', color: 'var(--red)', fontSize: 14, fontWeight: 600,
              border: '1px solid rgba(255,71,87,0.3)', cursor: 'pointer',
            }}
          >
            Log Out
          </button>
        )}
      </div>
    </div>
  );
}
